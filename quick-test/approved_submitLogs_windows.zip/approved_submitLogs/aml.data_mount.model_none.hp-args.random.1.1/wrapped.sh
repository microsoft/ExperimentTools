echo ----- START of XT-level processing -----
echo running: wrapped.sh
echo initial cwd: $PWD
echo running: mkdir ~/.xt/cwd -p
mkdir ~/.xt/cwd -p
echo CONDA: $CONDA_DEFAULT_ENV
echo initial PIP FREEZE:
pip freeze > __initial_pip_freeze__.log
echo running: pip install --user torch==1.2.0 torchvision==0.4.1 Pillow==6.2.0 watchdog==0.9.0 xtlib==0.0.196 > __pip_install__.log
pip install --user torch==1.2.0 torchvision==0.4.1 Pillow==6.2.0 watchdog==0.9.0 xtlib==0.0.196 > __pip_install__.log
echo after: pip install --user torch==1.2.0 torchvision==0.4.1 Pillow==6.2.0 watchdog==0.9.0 xtlib==0.0.196 > __pip_install__.log
export PATH=$HOME/.local/bin:$PATH
export PYTHONPATH=.:$PYTHONPATH
echo '---------- MEMORY Report -----------:'
free -mh
echo '---------- CPU Report -----------:'
lscpu
echo '---------- GPU Report -----------:'
nvidia-smi
echo '---------- PYTHON/PYTHON3 Report -----------:'
python -V
python3 -V
export USER=rfernand
fusermount -u -q $HOME/mnt/workspace
rm -rf $HOME/mnt/workspace
echo MOUNTING $HOME/mnt/workspace to container quick-test
export XT_OUTPUT_DIR="$HOME/mnt/workspace/runs/run22/output"
export XT_OUTPUT_MNT="$HOME/mnt/workspace/runs/run22/output"
wget https://packages.microsoft.com/config/ubuntu/16.04/packages-microsoft-prod.deb
dpkg -i packages-microsoft-prod.deb
apt-get update
apt-get install blobfuse
mkdir $HOME/mnt/workspace -p
mkdir $HOME/blobfusetmp1 -p
echo accountName xtsandboxstorage > $HOME/fuse1.cfg
echo accountKey qfXOrW7bHQwVOSQ20ViTlsh4GRSmn4UwzbdMTkqqGlVt9sqtwHuWVyBR1XRGti3K1lVMIk4k0S1xgOz58eT4ag== >> $HOME/fuse1.cfg
echo containerName quick-test >> $HOME/fuse1.cfg
chmod 600 $HOME/fuse1.cfg
echo about to run blobfuse
blobfuse $HOME/mnt/workspace --tmp-path=$HOME/blobfusetmp1  --config-file=$HOME/fuse1.cfg  -o attr_timeout=240 -o entry_timeout=240 -o negative_timeout=120 -o allow_other 
echo just ran blobfuse, here is ls -l on mnt_dir
ls -l $HOME/mnt/workspace
fusermount -u -q /mnt/data
rm -rf /mnt/data
echo MOUNTING /mnt/data to container xts-data-xts
export XT_DATA_DIR="/mnt/data/mnist"
export XT_DATA_MNT="/mnt/data/mnist"
wget https://packages.microsoft.com/config/ubuntu/16.04/packages-microsoft-prod.deb
dpkg -i packages-microsoft-prod.deb
apt-get update
apt-get install blobfuse
mkdir /mnt/data -p
mkdir $HOME/blobfusetmp2 -p
echo accountName xtsandboxstorage > $HOME/fuse2.cfg
echo accountKey qfXOrW7bHQwVOSQ20ViTlsh4GRSmn4UwzbdMTkqqGlVt9sqtwHuWVyBR1XRGti3K1lVMIk4k0S1xgOz58eT4ag== >> $HOME/fuse2.cfg
echo containerName xts-data-xts >> $HOME/fuse2.cfg
chmod 600 $HOME/fuse2.cfg
echo about to run blobfuse
blobfuse /mnt/data --tmp-path=$HOME/blobfusetmp2  --config-file=$HOME/fuse2.cfg -o ro -o attr_timeout=240 -o entry_timeout=240 -o negative_timeout=120 -o allow_other 
echo just ran blobfuse, here is ls -l on mnt_dir
ls -l /mnt/data
echo final PIP FREEZE:
pip freeze > __final_pip_freeze__.log
python -u __run_controller__.py $*