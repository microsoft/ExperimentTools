import sys
sys.path.insert(0, '.')    # support for --xtlib-upload 
from xtlib.controller import run
run(multi_run_context_fn='__multi_run_context__.json', port=18861, is_aml=False)
