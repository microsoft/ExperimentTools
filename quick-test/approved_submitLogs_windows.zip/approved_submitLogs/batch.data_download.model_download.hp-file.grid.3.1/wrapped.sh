sudo apt install unzip
unzip -n xt_code.zip > __unzip__.log
echo ----- START of XT-level processing -----
echo running: wrapped.sh
echo initial cwd: $PWD
echo running: mkdir ~/.xt/cwd -p
mkdir ~/.xt/cwd -p
conda activate py36
echo CONDA: $CONDA_DEFAULT_ENV
echo initial PIP FREEZE:
pip freeze > __initial_pip_freeze__.log
echo running: pip install --user xtlib==0.0.196 > __pip_install__.log
pip install --user xtlib==0.0.196 > __pip_install__.log
echo after: pip install --user xtlib==0.0.196 > __pip_install__.log
export PATH=$HOME/.local/bin:$PATH
export PYTHONPATH=.:$PYTHONPATH
echo '---------- MEMORY Report -----------:'
free -mh
echo '---------- CPU Report -----------:'
lscpu
echo '---------- GPU Report -----------:'
nvidia-smi
echo '---------- PYTHON/PYTHON3 Report -----------:'
python -V
python3 -V
export PATH=$HOME/.local/bin:$PATH
export XT_NODE_ID=$1
echo MOUNTING $HOME/mnt/workspace to container quick-test
export XT_OUTPUT_DIR="$HOME/mnt/workspace/runs/fake_run123/output"
export XT_OUTPUT_MNT="$HOME/mnt/workspace/runs/fake_run123/output"
mkdir $HOME/mnt/workspace -p
chown $USER $HOME/mnt/workspace
mkdir $HOME/blobfusetmp1 -p
echo accountName xtsandboxstorage > $HOME/fuse1.cfg
echo accountKey qfXOrW7bHQwVOSQ20ViTlsh4GRSmn4UwzbdMTkqqGlVt9sqtwHuWVyBR1XRGti3K1lVMIk4k0S1xgOz58eT4ag== >> $HOME/fuse1.cfg
echo containerName quick-test >> $HOME/fuse1.cfg
chmod 600 $HOME/fuse1.cfg
echo about to run blobfuse
blobfuse $HOME/mnt/workspace --tmp-path=$HOME/blobfusetmp1  --config-file=$HOME/fuse1.cfg  -o attr_timeout=240 -o entry_timeout=240 -o negative_timeout=120  
echo just ran blobfuse, here is ls -l on mnt_dir
ls -l $HOME/mnt/workspace
echo DOWNLOADING $HOME/mnt/data from container xts-data-xts
export XT_DATA_DIR="$HOME/mnt/data/mnist"
mkdir $HOME/mnt/data/mnist -p
chown $USER $HOME/mnt/data/mnist
echo running: xt download /xts-data-xts/mnist $HOME/mnt/data/mnist
xt download /xts-data-xts/mnist $HOME/mnt/data/mnist
echo after: xt download /xts-data-xts/mnist $HOME/mnt/data/mnist
echo DOWNLOADING $HOME/mnt/models from container xts-models-xts
export XT_MODEL_DIR="$HOME/mnt/models/miniMnist"
mkdir $HOME/mnt/models/miniMnist -p
chown $USER $HOME/mnt/models/miniMnist
echo running: xt download /xts-models-xts/miniMnist $HOME/mnt/models/miniMnist
xt download /xts-models-xts/miniMnist $HOME/mnt/models/miniMnist
echo after: xt download /xts-models-xts/miniMnist $HOME/mnt/models/miniMnist
echo final PIP FREEZE:
pip freeze > __final_pip_freeze__.log
python -u __run_controller__.py